const { describe, it, expect } = require('@jest/globals');

describe('Analytics Service', () => {
  it('should be able to run tests', () => {
    expect(true).toBe(true);
  });
});
