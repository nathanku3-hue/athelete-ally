const { describe, it, expect } = require('@jest/globals');

describe('Exercises Service', () => {
  it('should be able to run tests', () => {
    expect(true).toBe(true);
  });
});

