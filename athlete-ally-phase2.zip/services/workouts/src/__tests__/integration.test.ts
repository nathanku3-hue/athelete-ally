const { describe, it, expect } = require('@jest/globals');

describe('Workouts Service', () => {
  it('should be able to run tests', () => {
    expect(true).toBe(true);
  });
});

