// 敏感信息脱敏工具
export class SensitiveDataMasker {
  private static readonly SENSITIVE_PATTERNS = [
    // 密码相关
    /password["\s]*[:=]["\s]*[^"'\s,}]+/gi,
    /passwd["\s]*[:=]["\s]*[^"'\s,}]+/gi,
    /pwd["\s]*[:=]["\s]*[^"'\s,}]+/gi,
    
    // 令牌相关
    /token["\s]*[:=]["\s]*[^"'\s,}]+/gi,
    /bearer["\s]*[:=]["\s]*[^"'\s,}]+/gi,
    /jwt["\s]*[:=]["\s]*[^"'\s,}]+/gi,
    /api[_-]?key["\s]*[:=]["\s]*[^"'\s,}]+/gi,
    
    // 数据库相关
    /database[_-]?url["\s]*[:=]["\s]*[^"'\s,}]+/gi,
    /db[_-]?url["\s]*[:=]["\s]*[^"'\s,}]+/gi,
    /connection[_-]?string["\s]*[:=]["\s]*[^"'\s,}]+/gi,
    
    // 用户信息
    /user[_-]?id["\s]*[:=]["\s]*[^"'\s,}]+/gi,
    /email["\s]*[:=]["\s]*[^"'\s,}]+/gi,
    /phone["\s]*[:=]["\s]*[^"'\s,}]+/gi,
    
    // 其他敏感信息
    /secret["\s]*[:=]["\s]*[^"'\s,}]+/gi,
    /private[_-]?key["\s]*[:=]["\s]*[^"'\s,}]+/gi,
    /access[_-]?key["\s]*[:=]["\s]*[^"'\s,}]+/gi,
  ];

  private static readonly MASK_CHAR = '*';
  private static readonly MASK_LENGTH = 8;

  /**
   * 脱敏敏感信息
   */
  static maskSensitiveData(data: any): any {
    if (typeof data === 'string') {
      return this.maskString(data);
    }
    
    if (typeof data === 'object' && data !== null) {
      if (Array.isArray(data)) {
        return data.map(item => this.maskSensitiveData(item));
      }
      
      const masked: any = {};
      for (const [key, value] of Object.entries(data)) {
        // 检查key是否包含敏感信息
        if (this.isSensitiveKey(key)) {
          masked[key] = this.maskValue(value);
        } else {
          masked[key] = this.maskSensitiveData(value);
        }
      }
      return masked;
    }
    
    return data;
  }

  /**
   * 脱敏字符串
   */
  private static maskString(str: string): string {
    let masked = str;
    
    for (const pattern of this.SENSITIVE_PATTERNS) {
      masked = masked.replace(pattern, (match) => {
        const parts = match.split(/[:=]/);
        if (parts.length === 2) {
          const key = parts[0].trim();
          const value = parts[1].trim().replace(/["']/g, '');
          return `${key}: "${this.maskValue(value)}"`;
        }
        return match;
      });
    }
    
    return masked;
  }

  /**
   * 检查key是否敏感
   */
  private static isSensitiveKey(key: string): boolean {
    const lowerKey = key.toLowerCase();
    return this.SENSITIVE_PATTERNS.some(pattern => 
      pattern.test(lowerKey)
    );
  }

  /**
   * 脱敏值
   */
  private static maskValue(value: any): string {
    if (typeof value === 'string') {
      if (value.length <= 4) {
        return this.MASK_CHAR.repeat(4);
      }
      if (value.length <= this.MASK_LENGTH) {
        return this.MASK_CHAR.repeat(value.length);
      }
      return value.substring(0, 2) + this.MASK_CHAR.repeat(this.MASK_LENGTH - 4) + value.substring(value.length - 2);
    }
    return this.MASK_CHAR.repeat(this.MASK_LENGTH);
  }
}

// 安全的日志记录器
export class SafeLogger {
  private static isProduction = process.env.NODE_ENV === 'production';

  /**
   * 安全记录错误
   */
  static error(message: string, error?: any, context?: any): void {
    const maskedError = error ? SensitiveDataMasker.maskSensitiveData(error) : undefined;
    const maskedContext = context ? SensitiveDataMasker.maskSensitiveData(context) : undefined;
    
    if (this.isProduction) {
      // 生产环境只记录必要信息
      console.error(`[ERROR] ${message}`, {
        error: maskedError ? this.sanitizeError(maskedError) : undefined,
        context: maskedContext ? this.sanitizeContext(maskedContext) : undefined,
        timestamp: new Date().toISOString()
      });
    } else {
      // 开发环境记录详细信息
      console.error(`[ERROR] ${message}`, maskedError, maskedContext);
    }
  }

  /**
   * 安全记录警告
   */
  static warn(message: string, context?: any): void {
    const maskedContext = context ? SensitiveDataMasker.maskSensitiveData(context) : undefined;
    
    if (this.isProduction) {
      console.warn(`[WARN] ${message}`, {
        context: maskedContext ? this.sanitizeContext(maskedContext) : undefined,
        timestamp: new Date().toISOString()
      });
    } else {
      console.warn(`[WARN] ${message}`, maskedContext);
    }
  }

  /**
   * 安全记录信息
   */
  static info(message: string, context?: any): void {
    const maskedContext = context ? SensitiveDataMasker.maskSensitiveData(context) : undefined;
    
    if (this.isProduction) {
      console.log(`[INFO] ${message}`, {
        context: maskedContext ? this.sanitizeContext(maskedContext) : undefined,
        timestamp: new Date().toISOString()
      });
    } else {
      console.log(`[INFO] ${message}`, maskedContext);
    }
  }

  /**
   * 清理错误信息
   */
  private static sanitizeError(error: any): any {
    if (error instanceof Error) {
      return {
        name: error.name,
        message: error.message,
        stack: this.isProduction ? undefined : error.stack
      };
    }
    return error;
  }

  /**
   * 清理上下文信息
   */
  private static sanitizeContext(context: any): any {
    // 移除可能包含敏感信息的字段
    const sensitiveFields = ['password', 'token', 'secret', 'key', 'url', 'email', 'phone'];
    const sanitized = { ...context };
    
    for (const field of sensitiveFields) {
      if (field in sanitized) {
        delete sanitized[field];
      }
    }
    
    return sanitized;
  }
}

// 导出便捷方法
export const safeLog = SafeLogger;
export const maskData = SensitiveDataMasker.maskSensitiveData;
